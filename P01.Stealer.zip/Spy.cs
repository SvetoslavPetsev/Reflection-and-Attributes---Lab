﻿namespace Stealer
{
    using System;
    using System.Linq;
    using System.Reflection;
    using System.Text;

    public class Spy
    {
        public string StealFieldInfo(string nameOfTheClass, params string[] requestedFields)
        {
            Type classType = typeof(Hacker);
            var fields = classType.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);

            var classInstance = Activator.CreateInstance(classType, new object[] { });
            StringBuilder sb = new StringBuilder();
            
            sb.AppendLine($"Class under investigation: {nameOfTheClass}");
            foreach (var field in fields.Where(x => requestedFields.Contains(x.Name)))
            {
                sb.AppendLine($"{field.Name} = {field.GetValue(classInstance)}");
            }

            return sb.ToString().Trim();
        }
    }
}
