﻿namespace AuthorProblem
{
    using System;

    [Author("Ventsi")]
    public class StartUp
    {
        [Author("Gosho")]
        static void Main()
        {
        }
    }
}
